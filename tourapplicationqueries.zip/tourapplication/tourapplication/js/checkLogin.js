﻿function GetUserName() {

    var username = '<%= Session["UserName"] %>';
    alert(username);
}